# Firefly OS site

Static, zero-build landing page for GitHub Pages.

## Preview

```bash
python3 -m http.server 8000 -d .
```

Then open `http://localhost:8000/`.

## Language behavior

Priority:
1. `?lang=en` / `?lang=ru`
2. the user's saved choice (`localStorage`)
3. browser language/locale (`ru` or region `RU` → Russian)
4. English fallback

The EN/RU switch updates the page immediately and remembers the choice.

## Deploy to GitHub Pages

The directory is intentionally plain static HTML/CSS/JS. It can be deployed by a GitHub Pages workflow or copied into whatever Pages source directory the repository chooses. No framework or build step is required.

The Open Graph/canonical URLs currently assume the project Pages URL:
`https://hleserg.github.io/FireflyOS/`.
